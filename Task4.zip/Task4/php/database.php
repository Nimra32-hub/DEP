<?php
$db = mysqli_connect('localhost', 'root', '', 'newchatapp') or die("Database Not Connected !");
